import React, { useState, useRef, useEffect } from 'react';

// Define the structure of individual message bubbles in our conversation log
interface Message {
  role: 'user' | 'peer';
  text: string;
}

export default function App() {
  // Application State Control
  const [language, setLanguage] = useState<string>('English');
  const [inputText, setInputText] = useState<string>('');
  const [isSpeaking, setIsSpeaking] = useState<boolean>(false);
  const [textMode, setTextMode] = useState<boolean>(false);
  
  // Custom Identity Configurations (For user adjustments on the fly)
  const [voiceId, setVoiceId] = useState<string>('cloned_voice_id_here');
  const [faceUrl, setFaceUrl] = useState<string>('https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=600&auto=format&fit=crop&q=80');

  // Conversation history initialize
  const [transcript, setTranscript] = useState<Message[]>([
    { 
      role: 'peer', 
      text: 'Hey there! I am officially ready. You can completely change my face, voice clone profile, or language using the dashboard panel above.' 
    }
  ]);

  const chatEndRef = useRef<HTMLDivElement>(null);

  // Automatically scroll the chat container to the bottom whenever a new message appears
  useEffect(() => {
    chatEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [transcript]);

  // Handle message sending, backend pipeline simulations, and vocal output execution
  const handleSendMessage = () => {
    if (!inputText.trim()) return;

    const userMessage: Message = { role: 'user', text: inputText };
    const updatedTranscript = [...transcript, userMessage];
    
    setTranscript(updatedTranscript);
    const activePrompt = inputText;
    setInputText('');
    
    // Toggle speaking states to activate facial processing animations if text mode isn't forced
    if (!textMode) {
      setIsSpeaking(true);
    }

    // Simulate our custom human peer processing backend engine
    setTimeout(() => {
      let peerReply = '';

      if (language === 'Tamil') {
        // Human-like, casual conversational Tamil context checks
        if (activePrompt.includes('வணக்கம்') || activePrompt.toLowerCase().includes('hi') || activePrompt.toLowerCase().includes('hello')) {
          peerReply = 'வணக்கம் நண்பா! சொல்லுங்க, இன்னைக்கு நாம என்ன முக்கியமான வேலைய பார்க்க போறோம்? நான் ரெடியா இருக்கேன்.';
        } else {
          peerReply = 'சரிப்பா, நீங்க சொன்னது எனக்கு நல்லா புரிஞ்சது! இத நாம இப்போ உடனே ரொம்ப சிம்பிளா செஞ்சு முடிச்சிடலாம், கவலைப்படாதீங்க.';
        }
      } else {
        // Human-like, casual conversational English context checks
        if (activePrompt.toLowerCase().includes('hi') || activePrompt.toLowerCase().includes('hello') || activePrompt.toLowerCase().includes('hey')) {
          peerReply = "Hey! Great to see you. Honestly, I was just looking over some things—what are we diving into today?";
        } else {
          peerReply = "Yeah, I completely get what you mean. Honestly, let's just jump right into it and solve it this way. Makes total sense.";
        }
      }

      setTranscript([...updatedTranscript, { role: 'peer', text: peerReply }]);

      // Trigger the browser's audio processing layer if Text Mode is disabled
      if (!textMode) {
        // Cancel any active vocalizations to avoid overlapping audio artifacts
        window.speechSynthesis.cancel();

        const speechUtterance = new SpeechSynthesisUtterance(peerReply);
        speechUtterance.lang = language === 'Tamil' ? 'ta-IN' : 'en-US';
        speechUtterance.rate = 0.95; // Natural conversational cadence pacing adjustment
        speechUtterance.pitch = 1.0;

        // Automatically return face container to engine idle tracking when audio finishes
        speechUtterance.onend = () => {
          setIsSpeaking(false);
        };
        speechUtterance.onerror = () => {
          setIsSpeaking(false);
        };

        window.speechSynthesis.speak(speechUtterance);
      }
    }, 900); // Response scheduling delay simulation
  };

  return (
    <div style={{ fontFamily: '"Segoe UI", Roboto, Helvetica, Arial, sans-serif', background: '#0c0c0e', color: '#e2e8f0', height: '100vh', display: 'flex', flexDirection: 'column', overflow: 'hidden' }}>
      
      {/* Dynamic Settings & Configurations Bar */}
      <header style={{ padding: '16px 24px', background: '#16161a', display: 'flex', gap: '24px', flexWrap: 'wrap', alignItems: 'center', borderBottom: '1px solid #24242b', boxShadow: '0 4px 20px rgba(0,0,0,0.4)', zIndex: 10 }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
          <div style={{ width: '12px', height: '12px', background: '#3b82f6', borderRadius: '50%', animate: 'pulse 2s infinite' }}></div>
          <strong style={{ fontSize: '18px', color: '#fff', letterSpacing: '0.5px' }}>Human Twin Project</strong>
        </div>

        <div style={{ borderLeft: '1px solid #2d2d38', height: '30px' }}></div>

        {/* Language Selection Select Menu */}
        <div style={{ display: 'flex', flexDirection: 'column', gap: '4px' }}>
          <label style={{ fontSize: '11px', color: '#64748b', fontWeight: 600, textTransform: 'uppercase' }}>Language Interaction</label>
          <select value={language} onChange={(e) => setLanguage(e.target.value)} style={{ background: '#202024', color: '#fff', padding: '8px 14px', border: '1px solid #33333f', borderRadius: '8px', outline: 'none', fontSize: '13.5px', cursor: 'pointer' }}>
            <option value="English">English (US)</option>
            <option value="Tamil">Tamil (தமிழ்)</option>
          </select>
        </div>

        {/* ElevenLabs Dynamic Reference Entry Field */}
        <div style={{ display: 'flex', flexDirection: 'column', gap: '4px' }}>
          <label style={{ fontSize: '11px', color: '#64748b', fontWeight: 600, textTransform: 'uppercase' }}>ElevenLabs Cloned Voice ID</label>
          <input type="text" value={voiceId} onChange={(e) => setVoiceId(e.target.value)} placeholder="Enter Cloned ID..." style={{ background: '#202024', color: '#fff', padding: '8px 14px', border: '1px solid #33333f', borderRadius: '8px', width: '180px', outline: 'none', fontSize: '13.5px' }} />
        </div>

        {/* Face Image URL Source Relocator Box */}
        <div style={{ display: 'flex', flexDirection: 'column', gap: '4px' }}>
          <label style={{ fontSize: '11px', color: '#64748b', fontWeight: 600, textTransform: 'uppercase' }}>Target Photo Asset URL</label>
          <input type="text" value={faceUrl} onChange={(e) => setFaceUrl(e.target.value)} placeholder="Paste any Image URL..." style={{ background: '#202024', color: '#fff', padding: '8px 14px', border: '1px solid #33333f', borderRadius: '8px', width: '220px', outline: 'none', fontSize: '13.5px' }} />
        </div>

        <div style={{ marginLeft: 'auto', display: 'flex', alignItems: 'center' }}>
          <button onClick={() => { window.speechSynthesis.cancel(); setIsSpeaking(false); setTextMode(!textMode); }} style={{ background: textMode ? '#ef4444' : '#2563eb', color: '#fff', border: 'none', padding: '10px 18px', borderRadius: '8px', fontWeight: 600, fontSize: '13.5px', cursor: 'pointer', boxShadow: '0 4px 12px rgba(37,99,235,0.2)', transition: 'all 0.2s' }}>
            {textMode ? '📝 Mode: Text Reply' : '🗣️ Mode: Human Video'}
          </button>
        </div>
      </header>

      {/* Main UI Workspace Layout Partition */}
      <main style={{ flex: 1, display: 'flex', overflow: 'hidden' }}>
        
        {/* Left Side Section Panel Frame: Visual Human Presentation Grid */}
        <div style={{ width: '60%', background: '#09090b', display: 'flex', justifyContent: 'center', alignItems: 'center', position: 'relative', overflow: 'hidden' }}>
          
          {textMode ? (
            <div style={{ textAlign: 'center', color: '#4b5563' }}>
              <span style={{ fontSize: '48px', display: 'block', marginBottom: '12px' }}>📝</span>
              <p style={{ fontSize: '16px' }}>Visual Video Track Paused</p>
              <p style={{ fontSize: '13px', color: '#374151' }}>Running strictly in textual message replies mode</p>
            </div>
          ) : (
            <div style={{ width: '100%', height: '100%', display: 'flex', justifyContent: 'center', alignItems: 'center', position: 'relative' }}>
              
              {/* Photorealistic Human Face Target Display Render */}
              <img 
                src={faceUrl} 
                alt="Target Identity Frame"
                style={{ 
                  height: '100%', 
                  width: '100%', 
                  objectFit: 'cover',
                  transition: 'all 0.2s ease',
                  // Visual brightness scaling trick to mock real conversational response shifts
                  filter: isSpeaking ? 'brightness(1.15) contrast(1.05)' : 'brightness(0.9) contrast(1)'
                }} 
                onError={(e) => {
                  // Fallback safety filter if the user enters an invalid or broken image URL asset link
                  (e.target as HTMLImageElement).src = 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=600&auto=format&fit=crop&q=80';
                }}
              />

              {/* Real-time Processing Engine Overlay Banner */}
              <div style={{ position: 'absolute', top: '24px', left: '24px', background: 'rgba(15, 15, 20, 0.85)', backdropFilter: 'blur(8px)', border: '1px solid #2d2d3d', padding: '10px 20px', borderRadius: '40px', display: 'flex', alignItems: 'center', gap: '10px', fontSize: '13px', boxShadow: '0 4px 12px rgba(0,0,0,0.3)' }}>
                <span style={{ 
                  width: '10px', 
                  height: '10px', 
                  background: isSpeaking ? '#ef4444' : '#10b981', 
                  borderRadius: '50%', 
                  display: 'inline-block',
                  boxShadow: isSpeaking ? '0 0 10px #ef4444' : '0 0 10px #10b981',
                  transition: 'background 0.3s'
                }}></span>
                <span style={{ fontWeight: 500, color: '#f1f5f9' }}>
                  {isSpeaking ? 'Mouth Lip-Sync Tracking Active' : 'Human Idle Configuration (Breathing/Blinking)'}
                </span>
              </div>

            </div>
          )}
        </div>

        {/* Right Side Section Panel Frame: Conversation Log Stream */}
        <div style={{ width: '40%', display: 'flex', flexDirection: 'column', background: '#111115', borderLeft: '1px solid #1e1e24' }}>
          
          {/* Scrollable Conversation Container */}
          <div style={{ flex: 1, padding: '24px', overflowY: 'auto', display: 'flex', flexDirection: 'column', gap: '20px' }}>
            {transcript.map((msg, index) => (
              <div key={index} style={{ alignSelf: msg.role === 'user' ? 'flex-end' : 'flex-start', maxWidth: '85%' }}>
                {/* Meta Sender Tag Label */}
                <div style={{ fontSize: '11px', color: '#4b5563', fontWeight: 600, marginBottom: '4px', paddingLeft: msg.role === 'user' ? '0' : '4px', paddingRight: msg.role === 'user' ? '4px' : '0', textAlign: msg.role === 'user' ? 'right' : 'left' }}>
                  {msg.role === 'user' ? 'YOU' : 'YOUR FRIEND'}
                </div>
                
                {/* Text Dialogue Message Bubbles */}
                <div style={{ 
                  background: msg.role === 'user' ? '#2563eb' : '#1e1e24', 
                  color: '#ffffff', 
                  padding: '14px 18px', 
                  borderRadius: msg.role === 'user' ? '20px 20px 4px 20px' : '20px 20px 20px 4px', 
                  fontSize: '14.5px', 
                  lineHeight: '1.5',
                  border: msg.role === 'user' ? 'none' : '1px solid #2a2a35',
                  boxShadow: '0 4px 12px rgba(0,0,0,0.15)'
                }}>
                  {msg.text}
                </div>
              </div>
            ))}
            {/* Target Element Anchor Reference points */}
            <div ref={chatEndRef} />
          </div>

          {/* User Text Message Input Dock Footer Area */}
          <div style={{ padding: '20px 24px', background: '#16161a', borderTop: '1px solid #1e1e24', display: 'flex', gap: '12px', alignItems: 'center' }}>
            <input 
              type="text" 
              value={inputText} 
              onChange={(e) => setInputText(e.target.value)} 
              onKeyDown={(e) => e.key === 'Enter' && handleSendMessage()} 
              placeholder={language === 'Tamil' ? 'இங்கே டைப் செய்து உங்கள் நண்பரிடம் பேசுங்கள்...' : 'Type a text message to your peer companion here...'} 
              style={{ flex: 1, background: '#0c0c0e', color: '#fff', border: '1px solid #2a2a35', padding: '14px 16px', borderRadius: '12px', fontSize: '14.5px', outline: 'none', transition: 'border 0.2s' }} 
            />
            <button 
              onClick={handleSendMessage} 
              style={{ background: '#10b981', color: '#fff', border: 'none', padding: '14px 28px', borderRadius: '12px', fontSize: '14.5px', fontWeight: 600, cursor: 'pointer', boxShadow: '0 4px 12px rgba(16,185,129,0.2)', transition: 'background 0.2s' }}
            >
              Send
            </button>
          </div>

        </div>

      </main>
    </div>
  );
}